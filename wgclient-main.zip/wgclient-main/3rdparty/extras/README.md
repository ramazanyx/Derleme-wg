# CS16Client VGUI MENU Classic
classic menu for cs16client
