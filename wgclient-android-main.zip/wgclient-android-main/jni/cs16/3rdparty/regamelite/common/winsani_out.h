#if _MSC_VER >= 1500 // MSVC++ 9.0 (Visual Studio 2008)
#undef HSPRITE
#pragma pop_macro("ARRAYSIZE")
#endif
