# WgClient android port

this repo is synced client from WhyGhost's wgclient
(whyghost'a teşekkürler)

official repo:
https://github.com/whyGhosT/wgclient
